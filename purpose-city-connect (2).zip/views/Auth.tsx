
import React, { useState } from 'react';
import { Icons } from '../constants';

interface AuthProps {
  onJoin: (userData: { name: string; role: string }) => void;
}

const Auth: React.FC<AuthProps> = ({ onJoin }) => {
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [role, setRole] = useState('Member');

  const LogoIcon = ({ className = "w-24 h-24" }) => (
    <svg viewBox="0 0 100 100" className={className}>
      <circle cx="45" cy="35" r="18" fill="#F97316" />
      <g stroke="#F97316" strokeWidth="2">
        <line x1="45" y1="12" x2="45" y2="2" />
        <line x1="58" y1="18" x2="65" y2="10" />
        <line x1="32" y1="18" x2="25" y2="10" />
      </g>
      <path d="M45 35 L60 30 L60 80 L45 85 Z" fill="#D946EF" />
      <path d="M60 40 L75 45 L75 80 L60 75 Z" fill="#6D28D9" />
      <path d="M32 45 L45 40 L45 80 L32 75 Z" fill="#D946EF" opacity="0.8" />
      <path d="M30 85 Q50 65 75 85 L70 95 Q50 75 35 95 Z" fill="#6D28D9" />
    </svg>
  );

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-[#F97316] via-[#D946EF] to-[#6D28D9] flex items-center justify-center p-6 z-[200]">
      <div className="bg-white w-full max-w-md rounded-[3.5rem] p-10 shadow-2xl animate-in zoom-in-95 duration-500 text-center">
        
        {step === 1 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
            <div className="flex justify-center">
              <LogoIcon />
            </div>
            <div className="space-y-2">
              <h1 className="text-3xl font-black text-slate-900 tracking-tight">Purpose City <span className="text-purple-700">Connect</span></h1>
              <p className="text-slate-500 font-medium">Welcome to your digital church home. A space for growth, prayer, and family.</p>
            </div>
            <button 
              onClick={() => setStep(2)}
              className="w-full bg-slate-900 text-white py-6 rounded-3xl font-black uppercase tracking-widest text-xs hover:bg-purple-700 shadow-xl transition-all"
            >
              Get Started
            </button>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Est. 2024 • Build the Kingdom</p>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
            <div className="text-left space-y-2">
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">Who are you?</h2>
              <p className="text-sm text-slate-500">Every member has a place here. Let us know your name.</p>
            </div>
            <div className="space-y-4">
              <input 
                type="text" 
                placeholder="Your Full Name" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-50 border-none rounded-2xl px-6 py-5 text-sm font-bold focus:ring-4 focus:ring-purple-50 transition-all outline-none"
              />
              <select 
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full bg-slate-50 border-none rounded-2xl px-6 py-5 text-sm font-bold focus:ring-4 focus:ring-purple-50 transition-all outline-none"
              >
                <option>Member</option>
                <option>Life Group Leader</option>
                <option>Ministry Volunteer</option>
                <option>Youth Member</option>
                <option>Visitor</option>
              </select>
            </div>
            <button 
              disabled={!name.trim()}
              onClick={() => onJoin({ name, role })}
              className="w-full bg-gradient-to-r from-orange-500 to-fuchsia-600 text-white py-6 rounded-3xl font-black uppercase tracking-widest text-xs shadow-xl hover:scale-[1.02] active:scale-95 disabled:opacity-50 transition-all"
            >
              Join the Family
            </button>
          </div>
        )}

      </div>
    </div>
  );
};

export default Auth;
