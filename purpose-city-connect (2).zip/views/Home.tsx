
import React, { useEffect, useState } from 'react';
import { Icons, COLORS } from '../constants';
import { geminiService } from '../services/geminiService';
import { NewsItem, Post } from '../types';

interface HomeProps {
  user: { name: string; role: string };
}

const Home: React.FC<HomeProps> = ({ user }) => {
  const [dailyEncouragement, setDailyEncouragement] = useState<string>('Preparing your prophetic word...');
  const [isLive, setIsLive] = useState(true); // Simulated live status
  
  const news: NewsItem[] = [
    {
      id: '1',
      title: 'Global Youth Conference 2024',
      content: 'A life-changing weekend of worship, connection, and spiritual breakthroughs. Registration now open!',
      author: 'Media Team',
      date: 'Aug 15',
      category: 'Event',
      image: 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?auto=format&fit=crop&q=80&w=800'
    },
    {
      id: '2',
      title: 'Expansion Project Update',
      content: 'See how God is moving through our building campaign and our vision for the local community.',
      author: 'Board',
      date: 'Aug 12',
      category: 'Announcement',
      image: 'https://images.unsplash.com/photo-1541339907198-e08756ebafe3?auto=format&fit=crop&q=80&w=800'
    }
  ];

  useEffect(() => {
    const fetchEncouragement = async () => {
      const msg = await geminiService.generateDailyEncouragement();
      setDailyEncouragement(msg || '');
    };
    fetchEncouragement();
  }, []);

  return (
    <div className="space-y-16">
      <header className="text-left animate-in fade-in slide-in-from-left-4 duration-500">
         <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-400 mb-2">Welcome Back</p>
         <h1 className="text-4xl font-black text-slate-900 tracking-tight">Grace to you, <span className="text-purple-700">{user.name.split(' ')[0]}</span>.</h1>
      </header>

      {/* Live Indicator */}
      {isLive && (
        <div className="bg-slate-900 rounded-[2rem] p-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl border-l-8 border-red-600 animate-in fade-in slide-in-from-top-4">
           <div className="flex items-center gap-6">
              <div className="relative">
                 <div className="w-3 h-3 bg-red-600 rounded-full animate-ping absolute"></div>
                 <div className="w-3 h-3 bg-red-600 rounded-full"></div>
              </div>
              <div>
                 <h4 className="text-white font-black tracking-tight text-lg leading-tight uppercase">Sunday Service is LIVE</h4>
                 <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">Watching: 1,242 Saints Online</p>
              </div>
           </div>
           <div className="flex gap-3 w-full md:w-auto">
              <button className="flex-1 md:flex-none bg-white text-slate-900 px-8 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-100 transition-all">Watch Stream</button>
           </div>
        </div>
      )}

      {/* Hero: Prophetic Word */}
      <section className="bg-gradient-to-br from-[#F97316] via-[#D946EF] to-[#6D28D9] rounded-[3rem] p-10 md:p-16 text-white shadow-[0_30px_60px_-15px_rgba(109,40,217,0.4)] overflow-hidden relative group">
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-10">
            <div className="bg-white/20 p-4 rounded-[1.8rem] backdrop-blur-md shadow-inner border border-white/10">
              <Icons.Sparkles />
            </div>
            <span className="text-[10px] font-black uppercase tracking-[0.5em] opacity-80">DAILY BREAD</span>
          </div>
          <p className="text-3xl md:text-5xl font-black leading-tight italic max-w-3xl drop-shadow-[0_10px_10px_rgba(0,0,0,0.1)]">
            "{dailyEncouragement}"
          </p>
          <div className="mt-12">
            <button className="bg-white text-purple-700 px-10 py-5 rounded-[1.8rem] font-black uppercase tracking-widest text-xs shadow-2xl hover:scale-105 transition-all">
              Amen, Praise Him
            </button>
          </div>
        </div>
        <div className="absolute top-10 right-10 w-64 h-64 bg-orange-400/30 rounded-full blur-[100px] animate-pulse"></div>
      </section>

      {/* Quick Action Hub */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-6">
         {[
           { label: 'Prayer wall', icon: '🕊️', path: '/prayer' },
           { label: 'Sermon Archive', icon: '📽️', path: '/resources' },
           { label: 'Giving Hub', icon: '💎', path: '/giving' },
           { label: 'Life Groups', icon: '👥', path: '/community' }
         ].map((act, i) => (
           <a href={`#${act.path}`} key={i} className="bg-white p-8 rounded-[2rem] border border-slate-50 shadow-sm flex flex-col items-center text-center hover:shadow-xl hover:border-purple-200 transition-all group">
              <span className="text-4xl mb-4 group-hover:scale-125 transition-transform">{act.icon}</span>
              <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 group-hover:text-purple-700 transition-colors">{act.label}</span>
           </a>
         ))}
      </section>

      {/* News */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">The <span className="text-purple-700">Chronicle</span></h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {news.map(item => (
            <div key={item.id} className="bg-white rounded-[2.5rem] overflow-hidden shadow-sm border border-slate-50 hover:shadow-2xl transition-all duration-500 group">
              <div className="h-72 overflow-hidden relative">
                <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                <div className="absolute bottom-6 left-8 z-20">
                  <span className={`text-[9px] font-black uppercase tracking-[0.3em] px-5 py-2.5 rounded-[1.2rem] shadow-xl ${
                    item.category === 'Event' ? 'bg-orange-500 text-white' : 'bg-fuchsia-600 text-white'
                  }`}>
                    {item.category}
                  </span>
                </div>
              </div>
              <div className="p-10 text-left">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">{item.date}</p>
                <h3 className="text-2xl font-black text-slate-800 mb-4 tracking-tight group-hover:text-purple-700 transition-colors">{item.title}</h3>
                <p className="text-base text-slate-500 leading-relaxed font-medium mb-8 line-clamp-2">{item.content}</p>
                <div className="flex items-center text-xs font-black text-purple-700 tracking-widest gap-2">
                  LEARN MORE <span className="text-xl">→</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
