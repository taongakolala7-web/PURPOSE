
import React, { useState } from 'react';
import { Icons } from '../constants';

const PrayerWall: React.FC = () => {
  const [requests, setRequests] = useState([
    { id: 1, type: 'Request', user: 'Maria G.', text: "Please pray for my mother's surgery scheduled for this Thursday morning. We are trusting in God's healing hand.", prayedCount: 12, date: '1h ago', category: 'Health' },
    { id: 2, type: 'Praise', user: 'David K.', text: "HUGE Praise Report! I finally found a new job after 4 months of searching. God is faithful!", prayedCount: 45, date: '5h ago', category: 'Provision' },
    { id: 3, type: 'Request', user: 'Anonymous', text: "Struggling with peace in my family life. Asking for strength to be a lighthouse of love.", prayedCount: 8, date: '12h ago', category: 'Family' }
  ]);

  const handlePrayed = (id: number) => {
    setRequests(requests.map(req => req.id === id ? { ...req, prayedCount: req.prayedCount + 1 } : req));
  };

  return (
    <div className="space-y-12">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="max-w-xl">
          <h1 className="text-4xl font-black text-slate-900 tracking-tight mb-4">Prayer <span className="text-fuchsia-600">Wall</span></h1>
          <p className="text-lg text-slate-500 font-medium">Post your requests or join in intercession for the Purpose City family.</p>
        </div>
        <button className="bg-gradient-to-br from-fuchsia-500 to-purple-700 text-white px-10 py-5 rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center gap-3 shrink-0">
          <Icons.Plus /> New Request
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-orange-50 p-8 rounded-[2.5rem] border border-orange-100 flex items-center gap-6">
           <div className="text-4xl">🕊️</div>
           <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-orange-600 mb-1">Weekly Focus</p>
              <h4 className="text-lg font-black text-slate-800 tracking-tight">Peace in our Local Community</h4>
           </div>
        </div>
        <div className="bg-purple-50 p-8 rounded-[2.5rem] border border-purple-100 flex items-center gap-6">
           <div className="text-4xl">🔥</div>
           <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-purple-600 mb-1">Wall Impact</p>
              <h4 className="text-lg font-black text-slate-800 tracking-tight">342 Prayers offered this week</h4>
           </div>
        </div>
      </div>

      <div className="space-y-6">
        {requests.map(req => (
          <div key={req.id} className="bg-white p-8 rounded-[2.8rem] shadow-sm border border-slate-50 hover:shadow-lg transition-all relative overflow-hidden group">
            <div className={`absolute top-0 right-10 px-6 py-2 rounded-b-2xl text-[9px] font-black uppercase tracking-[0.3em] ${
              req.type === 'Praise' ? 'bg-emerald-500 text-white' : 'bg-orange-500 text-white'
            }`}>
              {req.type}
            </div>
            
            <div className="flex items-center gap-4 mb-6">
               <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center font-black text-slate-400">{req.user[0]}</div>
               <div>
                  <h4 className="font-black text-slate-800 tracking-tight">{req.user}</h4>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{req.category} • {req.date}</p>
               </div>
            </div>

            <p className="text-lg text-slate-700 leading-relaxed font-medium mb-8">
              {req.text}
            </p>

            <div className="flex items-center justify-between border-t border-slate-50 pt-8">
               <div className="flex items-center gap-2">
                  <div className="flex -space-x-2">
                     {[1,2,3].map(i => <div key={i} className="w-6 h-6 rounded-full border-2 border-white bg-slate-200" />)}
                  </div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{req.prayedCount} people are praying</span>
               </div>
               <button 
                onClick={() => handlePrayed(req.id)}
                className="bg-purple-50 hover:bg-purple-700 hover:text-white text-purple-700 px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-90"
               >
                 I Prayed
               </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PrayerWall;
