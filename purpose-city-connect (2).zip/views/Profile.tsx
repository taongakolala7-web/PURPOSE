
import React from 'react';
import { Icons } from '../constants';

interface ProfileProps {
  user: { name: string; role: string };
  onLogout: () => void;
}

const Profile: React.FC<ProfileProps> = ({ user, onLogout }) => {
  return (
    <div className="space-y-10">
      <section className="bg-white rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden group">
        <div className="h-48 bg-gradient-to-r from-orange-400 via-pink-500 to-violet-600 relative">
          <div className="absolute inset-0 bg-white/10 backdrop-blur-[2px]"></div>
        </div>
        <div className="px-8 pb-8 relative">
          <div className="flex flex-col md:flex-row md:items-end gap-6 -mt-16 mb-6">
            <div className="relative">
              <img 
                src={`https://api.dicebear.com/7.x/initials/svg?seed=${user.name}`} 
                alt="Me" 
                className="w-32 h-32 rounded-[2rem] border-8 border-white object-cover shadow-2xl bg-white"
              />
              <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-emerald-500 border-4 border-white rounded-full"></div>
            </div>
            <div className="flex-1 pt-2">
              <h1 className="text-3xl font-black text-slate-900 tracking-tight">{user.name}</h1>
              <p className="text-sm text-slate-500 font-bold uppercase tracking-widest mt-1">{user.role} • Purpose City Family</p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={onLogout}
                className="bg-red-50 text-red-600 px-8 py-3 rounded-2xl font-bold text-sm hover:bg-red-600 hover:text-white transition-all"
              >
                Sign Out
              </button>
            </div>
          </div>
          <div className="bg-slate-50 p-6 rounded-[1.5rem] border border-slate-100">
             <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-2">MY SPIRITUAL JOURNEY</h3>
             <p className="text-sm text-slate-600 leading-relaxed font-medium">
               I joined the Purpose City family to grow in my faith and serve my local community. Excited to connect with brothers and sisters here!
             </p>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1 space-y-8">
          <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm text-center">
            <h3 className="font-black text-slate-800 mb-6 text-lg uppercase tracking-widest">My Impact</h3>
            <div className="space-y-6">
              {[
                { label: 'Prayers Offered', val: '12', color: 'text-amber-500' },
                { label: 'Sermons Shared', val: '5', color: 'text-pink-500' },
                { label: 'Groups Joined', val: '1', color: 'text-violet-600' }
              ].map(stat => (
                <div key={stat.label} className="flex justify-between items-center group">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{stat.label}</span>
                  <span className={`text-lg font-black ${stat.color}`}>{stat.val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="md:col-span-2">
          <div className="bg-slate-900 p-10 rounded-[2.5rem] text-white relative overflow-hidden">
             <div className="relative z-10">
                <h3 className="text-2xl font-black mb-4 tracking-tight">Your Digital Member Card</h3>
                <p className="text-slate-400 text-sm mb-8">Show this card for check-in at events or volunteer service.</p>
                <div className="bg-white/10 p-6 rounded-2xl border border-white/10 inline-block">
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                         <LogoIcon className="w-10 h-10" />
                      </div>
                      <div className="text-left">
                         <p className="text-xs font-black opacity-60 uppercase tracking-widest">PCC MEMBER ID</p>
                         <p className="font-black">#000-842-{user.name.length}</p>
                      </div>
                   </div>
                </div>
             </div>
             <div className="absolute top-0 right-0 p-8 opacity-10">
                <Icons.Sparkles />
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const LogoIcon = ({ className = "w-10 h-10" }) => (
  <svg viewBox="0 0 100 100" className={className}>
    <circle cx="45" cy="35" r="18" fill="#F97316" />
    <g stroke="#F97316" strokeWidth="2">
      <line x1="45" y1="12" x2="45" y2="2" />
      <line x1="58" y1="18" x2="65" y2="10" />
      <line x1="32" y1="18" x2="25" y2="10" />
    </g>
    <path d="M45 35 L60 30 L60 80 L45 85 Z" fill="#D946EF" />
    <path d="M60 40 L75 45 L75 80 L60 75 Z" fill="#6D28D9" />
    <path d="M32 45 L45 40 L45 80 L32 75 Z" fill="#D946EF" opacity="0.8" />
    <path d="M30 85 Q50 65 75 85 L70 95 Q50 75 35 95 Z" fill="#6D28D9" />
  </svg>
);

export default Profile;
