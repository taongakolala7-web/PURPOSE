
import React from 'react';
import { Icons } from '../constants';

const Giving: React.FC = () => {
  const funds = [
    { title: 'Tithe & Offering', desc: 'Support our weekly ministry and operations.', goal: null, progress: null, icon: '🙏' },
    { title: 'Building Fund', desc: 'Contributing to our new sanctuary expansion.', goal: '$500,000', progress: 65, icon: '🏛️' },
    { title: 'Community Outreach', desc: 'Funding local food banks and clothing drives.', goal: '$10,000', progress: 82, icon: '🍞' }
  ];

  return (
    <div className="space-y-12">
      <header className="text-left max-w-2xl">
        <h1 className="text-4xl font-black text-slate-900 tracking-tight mb-4">Stewardship & <span className="text-purple-700">Blessing</span></h1>
        <p className="text-lg text-slate-500 font-medium leading-relaxed">
          "Each of you should give what you have decided in your heart to give, not reluctantly or under compulsion, for God loves a cheerful giver." — 2 Cor 9:7
        </p>
      </header>

      <section className="bg-gradient-to-br from-purple-700 to-fuchsia-600 rounded-[3rem] p-10 text-white shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-10">
          <div className="max-w-md">
            <h2 className="text-3xl font-black mb-4 tracking-tight">Express Giving</h2>
            <p className="text-purple-100 font-medium mb-8">Quickly send your tithe or offering using your saved payment method.</p>
            <div className="flex flex-wrap gap-4">
              {['$10', '$50', '$100', 'Custom'].map(amt => (
                <button key={amt} className="bg-white/20 hover:bg-white text-white hover:text-purple-700 px-8 py-4 rounded-2xl font-black transition-all">
                  {amt}
                </button>
              ))}
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/10 w-full md:w-80 shadow-inner">
             <div className="flex items-center gap-3 mb-6">
                <div className="bg-orange-500 w-12 h-12 rounded-xl flex items-center justify-center text-xl">💳</div>
                <div>
                   <p className="text-[10px] font-black uppercase opacity-60">Saved Method</p>
                   <p className="font-black">Visa •••• 4242</p>
                </div>
             </div>
             <button className="w-full bg-white text-purple-700 py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-lg hover:scale-105 active:scale-95 transition-all">
                Give Now
             </button>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {funds.map((fund, i) => (
          <div key={i} className="bg-white p-8 rounded-[2.5rem] border border-slate-50 shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all group">
            <div className="text-4xl mb-6 group-hover:scale-110 transition-transform inline-block">{fund.icon}</div>
            <h3 className="text-xl font-black text-slate-800 mb-2">{fund.title}</h3>
            <p className="text-sm text-slate-500 font-medium mb-8 leading-relaxed">{fund.desc}</p>
            
            {fund.progress !== null && (
              <div className="mb-8">
                <div className="flex justify-between text-[10px] font-black uppercase tracking-widest mb-3">
                   <span className="text-slate-400">Church Goal</span>
                   <span className="text-purple-700">{fund.progress}% Funded</span>
                </div>
                <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden p-0.5">
                   <div className="h-full bg-gradient-to-r from-orange-400 to-fuchsia-500 rounded-full transition-all duration-1000" style={{ width: `${fund.progress}%` }}></div>
                </div>
              </div>
            )}
            
            <button className="w-full bg-slate-50 group-hover:bg-purple-700 group-hover:text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
              Choose Fund
            </button>
          </div>
        ))}
      </div>
      
      <section className="bg-slate-900 rounded-[2.5rem] p-10 text-white flex flex-col md:flex-row items-center justify-between">
         <div className="max-w-md mb-8 md:mb-0">
            <h3 className="text-2xl font-black mb-2 tracking-tight">Giving History</h3>
            <p className="text-slate-400 font-medium">Download your tax statements or review your past generosity.</p>
         </div>
         <button className="bg-white/10 hover:bg-white/20 px-8 py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] transition-all">
            Download 2023 Statement
         </button>
      </section>
    </div>
  );
};

export default Giving;
