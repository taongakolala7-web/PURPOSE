
import { GoogleGenAI, Type } from "@google/genai";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async getSpiritualGuidance(prompt: string) {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          systemInstruction: "You are the 'Purpose Guide' for Purpose City Connect, a friendly AI assistant for a church community. You provide encouraging, biblically-based advice, help members find church resources, and answer questions about faith and community life. Keep answers warm, concise, and focused on growth.",
          temperature: 0.7,
        },
      });
      return response.text;
    } catch (error) {
      console.error("Gemini Error:", error);
      return "I'm sorry, I'm having a little trouble connecting right now. Let's pray together instead!";
    }
  }

  async generateDailyEncouragement() {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: "Generate a short, powerful daily encouragement for a church member. Include one bible verse.",
        config: {
          systemInstruction: "You are a prophetic and encouraging voice. Be poetic and impactful.",
        },
      });
      return response.text;
    } catch (error) {
      return "God's mercies are new every morning. Great is His faithfulness!";
    }
  }

  async summarizeSermon(sermonText: string) {
     try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Please summarize this sermon into 3 key takeaways and a short action step: ${sermonText}`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    summary: { type: Type.STRING },
                    takeaways: { type: Type.ARRAY, items: { type: Type.STRING } },
                    actionStep: { type: Type.STRING }
                },
                required: ["summary", "takeaways", "actionStep"]
            }
        }
      });
      return JSON.parse(response.text || '{}');
    } catch (error) {
      return null;
    }
  }
}

export const geminiService = new GeminiService();
