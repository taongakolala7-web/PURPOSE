
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Icons, COLORS } from '../constants';
import { geminiService } from '../services/geminiService';

interface LayoutProps {
  children: React.ReactNode;
  user: { name: string; role: string };
}

const LogoIcon = ({ className = "w-10 h-10" }) => (
  <svg viewBox="0 0 100 100" className={className}>
    <defs>
      <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#F97316" />
        <stop offset="50%" stopColor="#D946EF" />
        <stop offset="100%" stopColor="#6D28D9" />
      </linearGradient>
    </defs>
    <circle cx="45" cy="35" r="18" fill="#F97316" />
    <g stroke="#F97316" strokeWidth="2">
      <line x1="45" y1="12" x2="45" y2="2" />
      <line x1="58" y1="18" x2="65" y2="10" />
      <line x1="32" y1="18" x2="25" y2="10" />
      <line x1="28" y1="40" x2="15" y2="38" />
    </g>
    <path d="M45 35 L60 30 L60 80 L45 85 Z" fill="#D946EF" />
    <path d="M60 40 L75 45 L75 80 L60 75 Z" fill="#6D28D9" />
    <path d="M32 45 L45 40 L45 80 L32 75 Z" fill="#D946EF" opacity="0.8" />
    <rect x="48" y="42" width="2" height="4" fill="white" opacity="0.7" />
    <path d="M30 85 Q50 65 75 85 L70 95 Q50 75 35 95 Z" fill="#6D28D9" />
  </svg>
);

const Logo = () => (
  <div className="flex items-center gap-3">
    <LogoIcon className="w-12 h-12 drop-shadow-sm" />
    <div className="flex flex-col text-left">
      <h1 className="text-xl font-black tracking-tight text-slate-900 leading-[0.9]">
        PURPOSE <span className="text-purple-700">CITY</span>
      </h1>
      <p className="text-[9px] font-black tracking-[0.4em] text-slate-400 uppercase mt-1">CONNECT APP</p>
    </div>
  </div>
);

const Layout: React.FC<LayoutProps> = ({ children, user }) => {
  const location = useLocation();
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [aiMessage, setAiMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'ai', text: string }[]>([]);
  const [isTyping, setIsTyping] = useState(false);

  const navItems = [
    { path: '/', label: 'Home', icon: Icons.Home },
    { path: '/community', label: 'Connect', icon: Icons.Community },
    { path: '/prayer', label: 'Prayer', icon: Icons.Prayer },
    { path: '/resources', label: 'Library', icon: Icons.Resources },
    { path: '/giving', label: 'Giving', icon: Icons.Giving },
    { path: '/profile', label: 'Me', icon: Icons.Profile },
  ];

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiMessage.trim()) return;

    const userMsg = aiMessage;
    setChatHistory(prev => [...prev, { role: 'user', text: userMsg }]);
    setAiMessage('');
    setIsTyping(true);

    const response = await geminiService.getSpiritualGuidance(userMsg);
    setChatHistory(prev => [...prev, { role: 'ai', text: response || '' }]);
    setIsTyping(false);
  };

  return (
    <div className="flex h-screen bg-[#FDFEFF] overflow-hidden">
      <aside className="hidden md:flex flex-col w-72 bg-white border-r border-slate-100 shadow-[20px_0_50px_rgba(0,0,0,0.02)] z-20">
        <div className="p-10">
          <Logo />
        </div>
        
        <nav className="flex-1 px-6 space-y-2 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-4 px-6 py-4 rounded-3xl transition-all duration-300 ${
                  isActive 
                    ? 'bg-purple-50 text-purple-700 font-black shadow-inner translate-x-1' 
                    : 'text-slate-400 hover:bg-slate-50 hover:text-slate-700'
                }`}
              >
                <div className={`${isActive ? 'scale-110' : ''} transition-transform`}><item.icon /></div>
                <span className="text-xs uppercase tracking-widest">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-8">
          <button 
            onClick={() => setIsAiOpen(true)}
            className="w-full group flex items-center justify-center gap-3 bg-gradient-to-r from-orange-500 via-fuchsia-500 to-purple-700 text-white py-5 rounded-[2rem] font-black uppercase tracking-widest text-[10px] shadow-[0_15px_30px_rgba(109,40,217,0.3)] hover:shadow-[0_20px_40px_rgba(109,40,217,0.4)] hover:scale-[1.03] active:scale-[0.97] transition-all"
          >
            <Icons.Sparkles />
            Divine Guide
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <header className="h-24 bg-white/80 backdrop-blur-xl border-b border-slate-100 flex items-center justify-between px-8 sticky top-0 z-10">
          <div className="md:hidden">
            <LogoIcon className="w-10 h-10" />
          </div>
          <div className="hidden md:flex flex-1 max-w-xl">
            <div className="relative w-full">
              <span className="absolute inset-y-0 left-0 flex items-center pl-5 text-slate-300">
                <Icons.Search />
              </span>
              <input 
                type="text" 
                placeholder="Search resources..." 
                className="w-full pl-14 pr-6 py-3.5 bg-slate-50 border-none rounded-[1.5rem] text-sm font-medium focus:ring-2 focus:ring-purple-100 outline-none"
              />
            </div>
          </div>
          <div className="flex items-center gap-6">
            <button className="relative p-3 text-slate-400 hover:bg-slate-50 rounded-2xl transition-colors">
              <Icons.Bell />
              <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-orange-500 rounded-full border-2 border-white"></span>
            </button>
            <Link to="/profile" className="flex items-center gap-4 group">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-black text-slate-900 group-hover:text-purple-700 transition-colors">{user.name}</p>
                <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest">{user.role}</p>
              </div>
              <img src={`https://api.dicebear.com/7.x/initials/svg?seed=${user.name}`} className="w-12 h-12 rounded-[1.2rem] border-2 border-slate-50 object-cover shadow-md bg-white" />
            </Link>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 md:p-12 bg-[#FDFEFF]">
          <div className="max-w-5xl mx-auto pb-32">
            {children}
          </div>
        </div>

        <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t border-slate-100 flex justify-around items-center h-24 px-4 z-50">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center gap-1 p-2 transition-all ${isActive ? 'text-purple-700' : 'text-slate-300'}`}
              >
                <div className={`${isActive ? 'scale-110 -translate-y-1' : ''} transition-all`}><item.icon /></div>
                <span className={`text-[8px] font-black uppercase tracking-tighter ${isActive ? 'opacity-100' : 'opacity-60'}`}>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </main>

      {isAiOpen && (
        <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl flex flex-col h-[85vh] overflow-hidden animate-in slide-in-from-bottom-20">
            <div className="p-8 border-b border-slate-50 flex items-center justify-between bg-gradient-to-r from-orange-500 via-fuchsia-500 to-purple-700 text-white">
              <div className="flex items-center gap-5">
                <div className="bg-white/20 p-4 rounded-[1.5rem] backdrop-blur-md">
                  <Icons.Sparkles />
                </div>
                <div>
                  <h3 className="font-black text-xl tracking-tight">Divine Guide</h3>
                  <p className="text-[10px] font-black opacity-80 uppercase tracking-widest">Purpose City AI Assistant</p>
                </div>
              </div>
              <button onClick={() => setIsAiOpen(false)} className="p-4 hover:bg-white/10 rounded-[1.5rem] transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-8 space-y-8 bg-slate-50/30">
              {chatHistory.length === 0 && (
                <div className="text-center py-16 px-10">
                  <div className="bg-white w-24 h-24 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-sm text-fuchsia-500 animate-pulse">
                    <Icons.Sparkles />
                  </div>
                  <h4 className="font-black text-slate-800 text-3xl mb-4 tracking-tight">How can I bless you today?</h4>
                  <p className="text-slate-500 font-medium leading-relaxed mb-10">
                    I can help with prayer points, sermon recaps, or finding ministry groups.
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {['Morning Verse', 'Giving Impact', 'Find Prayer Wall', 'Latest Sermon'].map(tag => (
                      <button key={tag} onClick={() => setAiMessage(`I'd like to see ${tag.toLowerCase()}`)} className="bg-white border border-slate-100 px-5 py-4 rounded-2xl text-[9px] font-black uppercase tracking-widest text-slate-500 hover:border-purple-500 hover:text-purple-700 transition-all">
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {chatHistory.map((chat, i) => (
                <div key={i} className={`flex ${chat.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-6 rounded-[2rem] text-sm font-medium leading-relaxed ${
                    chat.role === 'user' ? 'bg-purple-700 text-white rounded-tr-none shadow-lg' : 'bg-white text-slate-800 rounded-tl-none border border-slate-50 shadow-sm'
                  }`}>
                    {chat.text}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white border border-slate-50 p-6 rounded-[2rem] rounded-tl-none flex gap-2">
                    <span className="w-2 h-2 bg-fuchsia-400 rounded-full animate-bounce"></span>
                    <span className="w-2 h-2 bg-fuchsia-400 rounded-full animate-bounce delay-100"></span>
                    <span className="w-2 h-2 bg-fuchsia-400 rounded-full animate-bounce delay-200"></span>
                  </div>
                </div>
              )}
            </div>

            <form onSubmit={handleSendMessage} className="p-8 border-t border-slate-50 bg-white">
              <div className="flex gap-4">
                <input type="text" value={aiMessage} onChange={(e) => setAiMessage(e.target.value)} placeholder="Type your request here..." className="flex-1 bg-slate-50 border-none rounded-[1.8rem] px-8 py-5 text-sm font-medium focus:ring-4 focus:ring-purple-50 transition-all outline-none" />
                <button type="submit" disabled={!aiMessage.trim() || isTyping} className="bg-gradient-to-br from-fuchsia-500 to-purple-700 text-white w-16 h-16 rounded-[1.5rem] flex items-center justify-center shadow-xl active:scale-90 shrink-0">
                  <Icons.Send />
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Layout;
