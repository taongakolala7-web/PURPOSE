
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './views/Home';
import Community from './views/Community';
import Resources from './views/Resources';
import Profile from './views/Profile';
import Giving from './views/Giving';
import PrayerWall from './views/PrayerWall';
import Auth from './views/Auth';

const App: React.FC = () => {
  const [user, setUser] = useState<{ name: string; role: string } | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('pcc_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const handleJoin = (userData: { name: string; role: string }) => {
    setUser(userData);
    localStorage.setItem('pcc_user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    localStorage.removeItem('pcc_user');
    setUser(null);
  };

  if (isLoading) return null;

  if (!user) {
    return <Auth onJoin={handleJoin} />;
  }

  return (
    <HashRouter>
      <Layout user={user}>
        <Routes>
          <Route path="/" element={<Home user={user} />} />
          <Route path="/community" element={<Community />} />
          <Route path="/prayer" element={<PrayerWall />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/giving" element={<Giving />} />
          <Route path="/profile" element={<Profile user={user} onLogout={handleLogout} />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
};

export default App;
