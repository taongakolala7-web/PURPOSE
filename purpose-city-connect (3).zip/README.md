# Purpose City Connect - Setup Guide

This is your custom church community platform. Follow these steps to get it live for your members.

## 1. Local Setup
1. Copy all project files into a folder on your computer.
2. Ensure you have [Node.js](https://nodejs.org/) installed.
3. Open your terminal in the folder and run:
   ```bash
   npm install
   npm start
   ```

## 2. Getting your AI Key
1. Go to [Google AI Studio](https://aistudio.google.com/).
2. Click "Get API Key".
3. Copy the key.

## 3. Deploying to the Web (Free)
We recommend **Vercel** for the fastest setup:
1. Upload your code to a **GitHub** repository.
2. Connect your GitHub to [Vercel](https://vercel.com).
3. **IMPORTANT:** Under "Project Settings" > "Environment Variables", add:
   - **Key:** `API_KEY`
   - **Value:** [Your Gemini API Key]
4. Click **Deploy**.

## 4. Mobile Installation
Once live, tell your members to:
- Open the link on their phone.
- Tap the **Share** icon (iOS) or **Menu** (Android).
- Select **"Add to Home Screen"**.
The app will now behave like a real app from the App Store!
