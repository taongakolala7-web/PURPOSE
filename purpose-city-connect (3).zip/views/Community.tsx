
import React from 'react';
import { Icons } from '../constants';

const Community: React.FC = () => {
  const groups = [
    { name: 'Worship Team', members: 12, category: 'Ministry' },
    { name: 'Young Adults', members: 45, category: 'Fellowship' },
    { name: 'Tech & Media', members: 8, category: 'Ministry' },
    { name: 'Outreach', members: 30, category: 'Mission' }
  ];

  const members = [
    { name: 'Pastor David', role: 'Lead Pastor', img: 'https://picsum.photos/seed/david/100/100' },
    { name: 'Sarah J.', role: 'Choir Lead', img: 'https://picsum.photos/seed/sarah/100/100' },
    { name: 'Marcus L.', role: 'Life Group Leader', img: 'https://picsum.photos/seed/marcus/100/100' },
    { name: 'Elena R.', role: 'New Member', img: 'https://picsum.photos/seed/elena/100/100' },
    { name: 'James W.', role: 'Member', img: 'https://picsum.photos/seed/james/100/100' }
  ];

  return (
    <div className="space-y-8">
      <header className="text-center md:text-left">
        <h1 className="text-3xl font-extrabold text-slate-900 mb-2">Connect & Grow</h1>
        <p className="text-slate-500 max-w-xl">Find your people. Purpose City is not just a building, it's a family of believers sharing life together.</p>
      </header>

      {/* Featured Groups */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-800">Life Groups & Ministries</h2>
          <button className="text-sm text-violet-600 font-semibold hover:underline">Explore More</button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {groups.map((group, i) => (
            <div key={i} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm hover:border-violet-200 hover:shadow-md transition-all cursor-pointer">
              <div className="bg-violet-50 w-10 h-10 rounded-xl flex items-center justify-center text-violet-600 mb-3">
                <Icons.Community />
              </div>
              <h3 className="font-bold text-sm text-slate-800">{group.name}</h3>
              <p className="text-[10px] text-slate-400 mt-1">{group.category} • {group.members} members</p>
            </div>
          ))}
        </div>
      </section>

      {/* Member Directory (Quick Look) */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-800">New & Active Members</h2>
          <div className="relative">
             <input 
              type="text" 
              placeholder="Filter members..." 
              className="pl-8 pr-3 py-1.5 bg-slate-100 rounded-full text-xs focus:ring-1 focus:ring-violet-500 outline-none"
             />
             <div className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400">
               <Icons.Search />
             </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm divide-y divide-slate-50">
          {members.map((member, i) => (
            <div key={i} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors first:rounded-t-2xl last:rounded-b-2xl">
              <div className="flex items-center gap-4">
                <img src={member.img} alt={member.name} className="w-12 h-12 rounded-full object-cover border border-slate-200" />
                <div>
                  <h4 className="font-bold text-slate-800">{member.name}</h4>
                  <p className="text-xs text-slate-500">{member.role}</p>
                </div>
              </div>
              <button className="bg-slate-100 hover:bg-violet-600 hover:text-white text-slate-600 px-4 py-1.5 rounded-full text-xs font-bold transition-all">
                Connect
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Discussion Topics */}
      <section className="bg-slate-900 rounded-3xl p-8 text-white relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-2xl font-bold mb-2">Join the Conversation</h2>
          <p className="text-slate-400 text-sm mb-6 max-w-md">Our community forum is active with discussions on theology, parenting, and career growth from a Christian perspective.</p>
          <button className="bg-violet-600 hover:bg-violet-700 text-white px-6 py-2.5 rounded-xl font-bold transition-colors">
            Go to Forum
          </button>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-violet-600/20 blur-[100px] rounded-full"></div>
      </section>
    </div>
  );
};

export default Community;
