
import React, { useState } from 'react';
import { Icons } from '../constants';
import { geminiService } from '../services/geminiService';

const Resources: React.FC = () => {
  const [summarizing, setSummarizing] = useState(false);
  const [summaryResult, setSummaryResult] = useState<any>(null);

  const sermons = [
    { title: 'The Power of Stillness', speaker: 'Pastor David', date: 'Aug 11, 2024', scripture: 'Psalm 46:10', text: "In a world that never stops talking, the voice of God is often found in the silence. Stillness is not inactivity, it is focused surrender. When we are still, we allow God to be the protagonist of our story..." },
    { title: 'Breaking the Cycle of Worry', speaker: 'Pastor John', date: 'Aug 04, 2024', scripture: 'Matthew 6:34', text: "Worry is like a rocking chair; it gives you something to do but gets you nowhere. Faith is the antidote to the poison of anxiety..." }
  ];

  const handleSummarize = async (text: string) => {
    setSummarizing(true);
    const result = await geminiService.summarizeSermon(text);
    setSummaryResult(result);
    setSummarizing(false);
    // Scroll to top of results
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 mb-2">Spiritual Resources</h1>
          <p className="text-slate-500">Dive deeper into the Word and review past teachings.</p>
        </div>
        <div className="flex gap-2">
          <button className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2">
            <Icons.Resources /> Library
          </button>
        </div>
      </header>

      {/* AI Summary Result */}
      {summaryResult && (
        <section className="bg-violet-50 rounded-3xl p-6 border border-violet-100 animate-in fade-in zoom-in duration-300">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-violet-800 flex items-center gap-2">
              <Icons.Sparkles /> AI Sermon Insights
            </h2>
            <button 
              onClick={() => setSummaryResult(null)}
              className="text-xs text-violet-400 hover:text-violet-600"
            >
              Clear
            </button>
          </div>
          <div className="space-y-4">
            <div>
              <h3 className="text-xs font-bold text-violet-600 uppercase mb-1">Key Summary</h3>
              <p className="text-sm text-slate-700 leading-relaxed">{summaryResult.summary}</p>
            </div>
            <div>
              <h3 className="text-xs font-bold text-violet-600 uppercase mb-1">Takeaways</h3>
              <ul className="list-disc list-inside space-y-1">
                {summaryResult.takeaways.map((t: string, i: number) => (
                  <li key={i} className="text-sm text-slate-700">{t}</li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-3 rounded-xl border border-violet-200">
              <h3 className="text-xs font-bold text-violet-600 uppercase mb-1">Action Step</h3>
              <p className="text-sm font-medium text-slate-800">{summaryResult.actionStep}</p>
            </div>
          </div>
        </section>
      )}

      {/* Sermon Archives */}
      <section>
        <h2 className="text-xl font-bold text-slate-800 mb-4">Sermon Archives</h2>
        <div className="space-y-4">
          {sermons.map((sermon, i) => (
            <div key={i} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 group">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-bold text-lg text-slate-800 group-hover:text-violet-600 transition-colors">{sermon.title}</h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-slate-500 flex items-center gap-1">
                      <Icons.Profile /> {sermon.speaker}
                    </span>
                    <span className="text-xs text-slate-500">•</span>
                    <span className="text-xs text-slate-500">{sermon.date}</span>
                  </div>
                </div>
                <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-[10px] font-bold">
                  {sermon.scripture}
                </span>
              </div>
              <p className="text-sm text-slate-500 mb-4 line-clamp-2 italic">
                "{sermon.text}"
              </p>
              <div className="flex gap-2">
                <button className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-2 rounded-xl text-xs font-bold transition-all">
                  Read Full Notes
                </button>
                <button 
                  onClick={() => handleSummarize(sermon.text)}
                  disabled={summarizing}
                  className="flex-1 bg-violet-600 hover:bg-violet-700 text-white py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {summarizing ? 'Analyzing...' : <><Icons.Sparkles /> AI Summary</>}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Study Materials */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-3xl border border-amber-100">
          <h3 className="font-bold text-amber-900 text-lg mb-2">Bible Study Guides</h3>
          <p className="text-amber-800/70 text-sm mb-4">Curated plans for individual or group study through the book of Acts.</p>
          <button className="text-amber-900 font-bold text-sm flex items-center gap-2 group">
            Download PDF <span className="group-hover:translate-x-1 transition-transform">→</span>
          </button>
        </div>
        <div className="bg-gradient-to-br from-emerald-50 to-teal-50 p-6 rounded-3xl border border-emerald-100">
          <h3 className="font-bold text-emerald-900 text-lg mb-2">Podcast Feed</h3>
          <p className="text-emerald-800/70 text-sm mb-4">Listen to our latest messages on the go with our daily devotionals.</p>
          <button className="text-emerald-900 font-bold text-sm flex items-center gap-2 group">
            Listen Now <span className="group-hover:translate-x-1 transition-transform">→</span>
          </button>
        </div>
      </section>
    </div>
  );
};

export default Resources;
