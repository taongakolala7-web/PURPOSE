
import React, { useState, useEffect } from 'react';
import { Icons } from '../constants';
import { geminiService } from '../services/geminiService';

interface ProfileProps {
  user: { name: string; role: string };
  onLogout: () => void;
}

const Profile: React.FC<ProfileProps> = ({ user, onLogout }) => {
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  
  const isAdmin = user.role.toLowerCase().includes('pastor') || 
                  user.role.toLowerCase().includes('leader') || 
                  user.name.toLowerCase().includes('admin');

  const runDiagnostics = async () => {
    setTestStatus('testing');
    const result = await geminiService.getSpiritualGuidance("Diagnostic Test");
    
    if (result === "KEY_MISSING") {
      setTestStatus('error');
      setErrorMessage("The 'API_KEY' variable is missing in Vercel settings.");
    } else if (result === "MODEL_NOT_AVAILABLE") {
      setTestStatus('error');
      setErrorMessage("The AI Model name is correct, but your key might not have access yet.");
    } else if (result?.includes("Connection Issue")) {
      setTestStatus('error');
      setErrorMessage(result);
    } else {
      setTestStatus('success');
    }
  };

  return (
    <div className="space-y-10 pb-20">
      {/* Profile Header */}
      <section className="bg-white rounded-[3rem] shadow-xl border border-slate-100 overflow-hidden">
        <div className="h-48 bg-gradient-to-br from-orange-400 via-fuchsia-500 to-purple-700 relative">
          <div className="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>
        </div>
        <div className="px-10 pb-10 relative">
          <div className="flex flex-col md:flex-row md:items-end gap-8 -mt-20">
            <div className="relative group">
              <img 
                src={`https://api.dicebear.com/7.x/initials/svg?seed=${user.name}`} 
                className="w-40 h-40 rounded-[2.5rem] border-8 border-white shadow-2xl bg-white group-hover:scale-105 transition-transform"
                alt="Avatar"
              />
              <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-emerald-500 border-4 border-white rounded-full shadow-lg"></div>
            </div>
            <div className="flex-1">
              <h1 className="text-4xl font-black text-slate-900 tracking-tight">{user.name}</h1>
              <p className="text-sm text-slate-400 font-black uppercase tracking-widest mt-2">{user.role} • Purpose City Family</p>
            </div>
            <button 
              onClick={onLogout}
              className="bg-red-50 text-red-600 px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-red-600 hover:text-white transition-all shadow-sm"
            >
              Sign Out
            </button>
          </div>
        </div>
      </section>

      {/* Diagnostics Panel */}
      {isAdmin && (
        <section className="bg-slate-900 rounded-[3rem] p-12 text-white shadow-2xl border-l-[12px] border-orange-500 relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-5 mb-10">
              <div className="bg-orange-500 p-4 rounded-2xl shadow-lg">
                <Icons.Sparkles />
              </div>
              <div>
                <h2 className="text-3xl font-black tracking-tight uppercase italic">System Restoration</h2>
                <p className="text-slate-400 text-sm font-medium">Verify your Vercel deployment and AI connectivity.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
              <div className="bg-white/5 p-8 rounded-3xl border border-white/10">
                <p className="text-[10px] font-black uppercase tracking-widest text-orange-400 mb-2">Step 1: Check Env</p>
                <p className="text-lg font-bold">{process.env.API_KEY ? '✅ Key Detected' : '❌ Key Missing'}</p>
              </div>
              <div className="bg-white/5 p-8 rounded-3xl border border-white/10">
                <p className="text-[10px] font-black uppercase tracking-widest text-orange-400 mb-2">Step 2: Routing</p>
                <p className="text-lg font-bold">✅ SPA Rewrites Active</p>
              </div>
            </div>

            <div className="space-y-6">
              <button 
                onClick={runDiagnostics}
                disabled={testStatus === 'testing'}
                className="w-full bg-white text-slate-900 py-6 rounded-[2rem] font-black uppercase tracking-widest text-xs hover:bg-orange-500 hover:text-white transition-all shadow-2xl disabled:opacity-50"
              >
                {testStatus === 'testing' ? 'Testing Connection...' : 'Run Full AI Diagnostic'}
              </button>

              {testStatus === 'success' && (
                <div className="bg-emerald-500/20 text-emerald-400 p-6 rounded-2xl text-center font-black uppercase tracking-widest text-[10px] border border-emerald-500/30">
                  ✅ Connection Restored! Purpose City AI is Live.
                </div>
              )}

              {testStatus === 'error' && (
                <div className="bg-red-500/20 text-red-400 p-6 rounded-2xl border border-red-500/30">
                  <p className="font-black uppercase tracking-widest text-[10px] mb-2">Error Detected</p>
                  <p className="text-sm font-medium opacity-90">{errorMessage}</p>
                </div>
              )}
            </div>
          </div>
          <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-orange-500/10 rounded-full blur-[100px]"></div>
        </section>
      )}

      {/* Toolbox */}
      <section className="bg-white rounded-[3rem] p-12 border border-slate-100 shadow-sm">
        <h3 className="text-2xl font-black text-slate-900 tracking-tight mb-8">Ministry Toolbox</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-50 p-8 rounded-3xl hover:shadow-lg transition-all cursor-pointer group">
            <h4 className="font-black text-slate-800 mb-2 group-hover:text-purple-700">Notifications</h4>
            <p className="text-xs text-slate-500 font-medium">Send push alerts to the congregation.</p>
          </div>
          <div className="bg-slate-50 p-8 rounded-3xl hover:shadow-lg transition-all cursor-pointer group">
            <h4 className="font-black text-slate-800 mb-2 group-hover:text-purple-700">Resources</h4>
            <p className="text-xs text-slate-500 font-medium">Upload PDF study guides or audio.</p>
          </div>
          <div className="bg-slate-50 p-8 rounded-3xl hover:shadow-lg transition-all cursor-pointer group">
            <h4 className="font-black text-slate-800 mb-2 group-hover:text-purple-700">Events</h4>
            <p className="text-xs text-slate-500 font-medium">Schedule and manage sanctuary bookings.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Profile;
