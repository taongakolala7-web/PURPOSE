
import { GoogleGenAI, Type } from "@google/genai";

export class GeminiService {
  private getAI() {
    const apiKey = process.env.API_KEY;
    // Note: process.env.API_KEY is automatically injected in this environment
    return new GoogleGenAI({ apiKey: apiKey || '' });
  }

  async getSpiritualGuidance(prompt: string) {
    // Try primary then fallback model
    const models = ['gemini-3-flash-preview', 'gemini-2.5-flash-lite-latest'];
    
    if (!process.env.API_KEY) {
      return "KEY_MISSING";
    }

    for (const modelName of models) {
      try {
        const ai = this.getAI();
        const response = await ai.models.generateContent({
          model: modelName,
          contents: prompt,
          config: {
            systemInstruction: "You are the 'Purpose Guide' for Purpose City Connect. Provide encouraging, biblically-based advice. Keep responses under 3 sentences. Be warm and pastoral.",
            temperature: 0.7,
          },
        });
        return response.text;
      } catch (error: any) {
        console.error(`Error with ${modelName}:`, error);
        if (error?.message?.includes("404") || error?.message?.includes("not found")) {
          continue; 
        }
        return `Connection Issue: ${error?.message || "Please check your network."}`;
      }
    }
    return "MODEL_NOT_AVAILABLE";
  }

  async generateDailyEncouragement() {
    try {
      const ai = this.getAI();
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: "Give me a one-sentence prophetic encouragement for today.",
      });
      return response.text;
    } catch (error) {
      return "Your steps are ordered by the Lord, and He delights in your way.";
    }
  }

  async summarizeSermon(sermonText: string) {
     try {
      const ai = this.getAI();
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Summarize this sermon into 3 bullet points: ${sermonText}`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    summary: { type: Type.STRING },
                    takeaways: { type: Type.ARRAY, items: { type: Type.STRING } },
                    actionStep: { type: Type.STRING }
                },
                required: ["summary", "takeaways", "actionStep"]
            }
        }
      });
      return JSON.parse(response.text || '{}');
    } catch (error) {
      return null;
    }
  }
}

export const geminiService = new GeminiService();
