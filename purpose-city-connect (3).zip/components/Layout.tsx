
import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Icons, COLORS } from '../constants';
import { geminiService } from '../services/geminiService';

interface LayoutProps {
  children: React.ReactNode;
  user: { name: string; role: string };
}

const LogoIcon = ({ className = "w-10 h-10" }) => (
  <svg viewBox="0 0 100 100" className={className}>
    <defs>
      <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#F97316" />
        <stop offset="50%" stopColor="#D946EF" />
        <stop offset="100%" stopColor="#6D28D9" />
      </linearGradient>
    </defs>
    <circle cx="45" cy="35" r="18" fill="#F97316" />
    <path d="M45 35 L60 30 L60 80 L45 85 Z" fill="#D946EF" />
    <path d="M60 40 L75 45 L75 80 L60 75 Z" fill="#6D28D9" />
    <path d="M32 45 L45 40 L45 80 L32 75 Z" fill="#D946EF" opacity="0.8" />
  </svg>
);

const Layout: React.FC<LayoutProps> = ({ children, user }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [aiMessage, setAiMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'ai', text: string, errorType?: string }[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatHistory, isTyping]);

  const navItems = [
    { path: '/', label: 'Home', icon: Icons.Home },
    { path: '/community', label: 'Connect', icon: Icons.Community },
    { path: '/prayer', label: 'Prayer', icon: Icons.Prayer },
    { path: '/resources', label: 'Library', icon: Icons.Resources },
    { path: '/giving', label: 'Giving', icon: Icons.Giving },
    { path: '/profile', label: 'Me', icon: Icons.Profile },
  ];

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiMessage.trim() || isTyping) return;

    const userMsg = aiMessage;
    setChatHistory(prev => [...prev, { role: 'user', text: userMsg }]);
    setAiMessage('');
    setIsTyping(true);

    const response = await geminiService.getSpiritualGuidance(userMsg);
    
    if (response === "KEY_MISSING" || response === "MODEL_NOT_AVAILABLE") {
      setChatHistory(prev => [...prev, { 
        role: 'ai', 
        text: "I'm having a little trouble with my connection. If you're the administrator, please check the 'System Restoration' guide on the Me (Profile) page.",
        errorType: response 
      }]);
    } else {
      setChatHistory(prev => [...prev, { role: 'ai', text: response || 'I am listening with an open heart.' }]);
    }
    setIsTyping(false);
  };

  return (
    <div className="flex h-screen bg-[#FDFEFF] overflow-hidden">
      {/* Sidebar Desktop */}
      <aside className="hidden md:flex flex-col w-80 bg-white border-r border-slate-100 shadow-2xl z-20">
        <div className="p-12">
          <div className="flex items-center gap-4">
            <LogoIcon className="w-14 h-14" />
            <div className="flex flex-col">
              <h1 className="text-xl font-black text-slate-900 leading-[0.8] tracking-tight">PURPOSE <span className="text-purple-700">CITY</span></h1>
              <p className="text-[9px] font-black uppercase tracking-[0.4em] text-slate-400 mt-2">CONNECT APP</p>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 px-8 space-y-3 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-5 px-8 py-5 rounded-[2rem] transition-all duration-300 ${
                  isActive 
                    ? 'bg-purple-50 text-purple-700 font-black shadow-inner border border-purple-100/50' 
                    : 'text-slate-400 hover:bg-slate-50 hover:text-slate-600'
                }`}
              >
                <div className={`${isActive ? 'scale-110' : ''}`}><item.icon /></div>
                <span className="text-[10px] uppercase tracking-[0.2em]">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-10">
          <button 
            onClick={() => setIsAiOpen(true)}
            className="w-full bg-gradient-to-r from-orange-500 to-purple-700 text-white py-6 rounded-[2rem] font-black uppercase tracking-widest text-[10px] shadow-2xl hover:scale-105 transition-all flex items-center justify-center gap-3"
          >
            <Icons.Sparkles /> Divine Guide
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-28 bg-white/80 backdrop-blur-xl border-b border-slate-100 flex items-center justify-between px-10 sticky top-0 z-10">
          <div className="md:hidden">
            <LogoIcon className="w-12 h-12" />
          </div>
          <div className="hidden md:flex flex-1 max-w-2xl ml-4">
             <div className="relative w-full">
                <span className="absolute inset-y-0 left-0 flex items-center pl-6 text-slate-300">
                  <Icons.Search />
                </span>
                <input 
                  type="text" 
                  placeholder="Find prayers, sermons, or groups..." 
                  className="w-full pl-16 pr-8 py-4 bg-slate-50 border-none rounded-[1.8rem] text-sm font-medium focus:ring-2 focus:ring-purple-100 outline-none transition-all"
                />
             </div>
          </div>
          <div className="flex items-center gap-8">
            <button className="relative p-4 text-slate-400 hover:bg-slate-50 rounded-[1.5rem] transition-colors">
              <Icons.Bell />
              <span className="absolute top-4 right-4 w-2.5 h-2.5 bg-orange-500 rounded-full border-4 border-white"></span>
            </button>
            <Link to="/profile" className="flex items-center gap-5 group">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-black text-slate-900 group-hover:text-purple-700 transition-colors">{user.name}</p>
                <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest">{user.role}</p>
              </div>
              <img src={`https://api.dicebear.com/7.x/initials/svg?seed=${user.name}`} className="w-14 h-14 rounded-[1.8rem] border-2 border-slate-50 object-cover shadow-lg bg-white" />
            </Link>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 md:p-16 bg-[#FDFEFF]">
          <div className="max-w-6xl mx-auto pb-32">
            {children}
          </div>
        </div>

        {/* Mobile Nav */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-2xl border-t border-slate-100 flex justify-around items-center h-28 px-6 z-50">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center gap-2 p-3 transition-all ${isActive ? 'text-purple-700' : 'text-slate-300'}`}
              >
                <div className={`${isActive ? 'scale-125 -translate-y-2' : ''} transition-all`}><item.icon /></div>
                <span className={`text-[8px] font-black uppercase tracking-tighter ${isActive ? 'opacity-100' : 'opacity-60'}`}>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </main>

      {/* AI Modal Chat */}
      {isAiOpen && (
        <div className="fixed inset-0 z-[200] flex items-end md:items-center justify-center bg-slate-900/40 backdrop-blur-md p-6">
          <div className="bg-white w-full max-w-2xl rounded-[3.5rem] shadow-[0_50px_100px_rgba(0,0,0,0.1)] flex flex-col h-[85vh] overflow-hidden animate-in slide-in-from-bottom-24 duration-500">
            <div className="p-10 border-b border-slate-50 flex items-center justify-between bg-gradient-to-r from-orange-500 via-fuchsia-500 to-purple-700 text-white">
              <div className="flex items-center gap-6">
                <div className="bg-white/20 p-5 rounded-[2rem] backdrop-blur-xl border border-white/20">
                  <Icons.Sparkles />
                </div>
                <div>
                  <h3 className="font-black text-2xl tracking-tight italic">Divine Guide</h3>
                  <p className="text-[10px] font-black opacity-80 uppercase tracking-widest mt-1">Spiritual Companion AI</p>
                </div>
              </div>
              <button onClick={() => setIsAiOpen(false)} className="p-5 hover:bg-white/10 rounded-3xl transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
              </button>
            </div>
            
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-10 space-y-10 bg-slate-50/30">
              {chatHistory.length === 0 && (
                <div className="text-center py-20 px-10">
                  <div className="bg-white w-28 h-28 rounded-[3rem] flex items-center justify-center mx-auto mb-10 shadow-sm text-fuchsia-500 animate-pulse">
                    <Icons.Sparkles />
                  </div>
                  <h4 className="font-black text-slate-800 text-4xl mb-6 tracking-tight italic">How can I pray with you?</h4>
                  <p className="text-slate-500 font-medium leading-relaxed mb-12 max-w-md mx-auto">
                    I am here to offer scripture, guidance, and encouragement as you walk in your purpose.
                  </p>
                  <div className="flex flex-wrap justify-center gap-4">
                    {['Morning Blessing', 'Prayer for Peace', 'Sermon Insight'].map(tag => (
                      <button key={tag} onClick={() => setAiMessage(`I need a ${tag.toLowerCase()}`)} className="bg-white border border-slate-100 px-8 py-5 rounded-[1.8rem] text-[10px] font-black uppercase tracking-widest text-slate-500 hover:border-purple-500 hover:text-purple-700 transition-all shadow-sm">
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {chatHistory.map((chat, i) => (
                <div key={i} className={`flex ${chat.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-8 rounded-[2.5rem] text-sm font-medium leading-relaxed shadow-sm ${
                    chat.role === 'user' ? 'bg-purple-700 text-white rounded-tr-none' : 
                    chat.errorType ? 'bg-red-50 text-red-900 border border-red-200 rounded-tl-none' :
                    'bg-white text-slate-800 rounded-tl-none border border-slate-100'
                  }`}>
                    {chat.text}
                    {chat.errorType && (
                      <button 
                        onClick={() => { setIsAiOpen(false); navigate('/profile'); }}
                        className="mt-6 block w-full bg-red-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest text-[9px] shadow-lg"
                      >
                        Open Restoration Hub
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white border border-slate-100 p-8 rounded-[2.5rem] rounded-tl-none flex gap-3">
                    <span className="w-2.5 h-2.5 bg-fuchsia-400 rounded-full animate-bounce"></span>
                    <span className="w-2.5 h-2.5 bg-fuchsia-400 rounded-full animate-bounce delay-100"></span>
                    <span className="w-2.5 h-2.5 bg-fuchsia-400 rounded-full animate-bounce delay-200"></span>
                  </div>
                </div>
              )}
            </div>

            <form onSubmit={handleSendMessage} className="p-10 border-t border-slate-50 bg-white">
              <div className="flex gap-5">
                <input 
                  type="text" 
                  value={aiMessage} 
                  onChange={(e) => setAiMessage(e.target.value)} 
                  placeholder="Share what's on your heart..." 
                  className="flex-1 bg-slate-50 border-none rounded-[2rem] px-10 py-6 text-sm font-medium focus:ring-4 focus:ring-purple-50 transition-all outline-none" 
                />
                <button 
                  type="submit" 
                  disabled={!aiMessage.trim() || isTyping} 
                  className="bg-gradient-to-br from-fuchsia-500 to-purple-700 text-white w-20 h-20 rounded-[1.8rem] flex items-center justify-center shadow-2xl active:scale-90 shrink-0 transition-transform disabled:opacity-50"
                >
                  <Icons.Send />
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Layout;
