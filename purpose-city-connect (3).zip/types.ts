
export interface UserProfile {
  id: string;
  name: string;
  role: string;
  bio: string;
  avatar: string;
  joinedDate: string;
  location: string;
}

export interface NewsItem {
  id: string;
  title: string;
  content: string;
  author: string;
  date: string;
  image: string;
  category: 'Announcement' | 'Event' | 'Sermon';
}

export interface Post {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  timestamp: string;
  likes: number;
  comments: number;
}

export interface SermonNote {
  id: string;
  title: string;
  preacher: string;
  date: string;
  summary: string;
  keyVerses: string[];
}
